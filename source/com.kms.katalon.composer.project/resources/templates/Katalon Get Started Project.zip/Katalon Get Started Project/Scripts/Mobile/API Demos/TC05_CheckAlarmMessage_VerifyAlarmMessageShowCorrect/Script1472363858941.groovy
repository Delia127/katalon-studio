import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.util.PathUtil


Mobile.tap(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - App'), GlobalVariable.G_Timeout)

Mobile.tap(findTestObject('Object Repository/Mobile/Application/App/android.widget.TextView-Activity'), GlobalVariable.G_Timeout)

Mobile.tap(findTestObject('Object Repository/Mobile/Application/App/Activity/android.widget.TextView-Custom Dialog'), GlobalVariable.G_Timeout)

def message = Mobile.getText(findTestObject('Object Repository/Mobile/Application/App/Activity/Custom Dialog/android.widget.TextViewCustomDialog'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(message, "Example of how you can use a custom Theme.Dialog theme to make an activity that looks like a customized dialog, here with an ugly frame.")

@com.kms.katalon.core.annotation.SetUp
def Setup() {
	def appPath = PathUtil.relativeToAbsolutePath(GlobalVariable.G_AndroidApp, RunConfiguration.getProjectDir())
	Mobile.startApplication(appPath, false)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	Mobile.closeApplication()
}