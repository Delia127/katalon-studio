import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.util.PathUtil

def text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Accessibility'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Accessibility")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Animation'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Animation")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - App'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "App")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Content'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Content")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Graphics'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Graphics")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Media'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Media")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - NFC'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "NFC")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - OS'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "OS")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Preference'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Preference")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Text'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Text")

text = Mobile.getText(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Views'), GlobalVariable.G_Timeout)

Mobile.verifyEqual(text, "Views")



@com.kms.katalon.core.annotation.SetUp
def Setup() {
	def appPath = PathUtil.relativeToAbsolutePath(GlobalVariable.G_AndroidApp, RunConfiguration.getProjectDir())	
	Mobile.startApplication(appPath, false)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	Mobile.closeApplication()
}

