import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration
import com.kms.katalon.core.util.PathUtil as PathUtil
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile

Mobile.tap(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Preference'), GlobalVariable.G_Timeout)

Mobile.tap(findTestObject('Object Repository/Mobile/Application/Preference/android.widget.Default values'), GlobalVariable.G_Timeout)

def attribute = Mobile.getAttribute(findTestObject('Object Repository/Mobile/Application/Preference/Default values/android.widget.CheckBox'), "checked",GlobalVariable.G_Timeout)

Mobile.verifyEqual(attribute, "true")

attribute = Mobile.getAttribute(findTestObject('Object Repository/Mobile/Application/Preference/Default values/android.widget.Switch'), "checked",GlobalVariable.G_Timeout)

Mobile.verifyEqual(attribute, "false")


@com.kms.katalon.core.annotation.SetUp
def Setup() {
	def appPath = PathUtil.relativeToAbsolutePath(GlobalVariable.G_AndroidApp, RunConfiguration.getProjectDir())
	Mobile.startApplication(appPath, false)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	Mobile.closeApplication()
}