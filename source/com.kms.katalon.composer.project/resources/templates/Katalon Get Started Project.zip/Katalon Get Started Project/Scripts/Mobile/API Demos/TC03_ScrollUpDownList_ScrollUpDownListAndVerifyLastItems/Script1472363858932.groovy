import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration
import com.kms.katalon.core.util.PathUtil as PathUtil


Mobile.tap(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - Graphics'), GlobalVariable.G_Timeout)
Mobile.scrollToText("Xfermodes")
def itemText = Mobile.getText(findTestObject('Object Repository/Mobile/Application/Graphics/android.widget.TextView - Xfermodes'), GlobalVariable.G_Timeout)
Mobile.verifyEqual(itemText, "Xfermodes")
Mobile.closeApplication()

@com.kms.katalon.core.annotation.SetUp
def Setup() {
	def appPath = PathUtil.relativeToAbsolutePath(GlobalVariable.G_AndroidApp, RunConfiguration.getProjectDir())
	Mobile.startApplication(appPath, false)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	Mobile.closeApplication()
}
