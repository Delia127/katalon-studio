import com.kms.katalon.core.configuration.RunConfiguration as RunConfiguration
import com.kms.katalon.core.util.PathUtil as PathUtil
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import internal.GlobalVariable as GlobalVariable

Mobile.tap(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - OS'), GlobalVariable.G_Timeout)

Mobile.tap(findTestObject('Object Repository/Mobile/Application/OS/android.widget.TextView - SMS Messaging'), GlobalVariable.G_Timeout)

Mobile.setText(findTestObject('Object Repository/Mobile/Application/OS/SMS Messaging/android.widget.EditRecipient'), 
    'Testing', GlobalVariable.G_Timeout)

Mobile.setText(findTestObject('Object Repository/Mobile/Application/OS/SMS Messaging/android.widget.EditMessageBody'), 
    'Testing', GlobalVariable.G_Timeout)

Mobile.tap(findTestObject('Mobile/Application/OS/SMS Messaging/android.widget.Button-Send'), GlobalVariable.G_Timeout)

def textAlert = Mobile.getText(findTestObject('Mobile/Application/OS/SMS Messaging/android.widget.TextView0-Unfortunately'), 
    GlobalVariable.G_Timeout)

Mobile.verifyEqual(textAlert, 'Unfortunately, API Demos has stopped.')

@com.kms.katalon.core.annotation.SetUp
def Setup() {
    def appPath = PathUtil.relativeToAbsolutePath(GlobalVariable.G_AndroidApp, RunConfiguration.getProjectDir())

    Mobile.startApplication(appPath, false)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	Mobile.closeApplication()
}


