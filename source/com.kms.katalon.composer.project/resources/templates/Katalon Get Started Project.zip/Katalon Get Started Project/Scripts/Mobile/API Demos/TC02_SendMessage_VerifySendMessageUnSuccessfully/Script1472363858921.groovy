import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.util.PathUtil

Mobile.tap(findTestObject('Object Repository/Mobile/Application/android.widget.TextView - OS'), GlobalVariable.G_Timeout)

Mobile.tap(findTestObject('Object Repository/Mobile/Application/OS/android.widget.TextView - SMS Messaging'), GlobalVariable.G_Timeout)

Mobile.setText(findTestObject('Object Repository/Mobile/Application/OS/SMS Messaging/android.widget.EditRecipient'), 
    'Testing', GlobalVariable.G_Timeout)

Mobile.setText(findTestObject('Object Repository/Mobile/Application/OS/SMS Messaging/android.widget.EditMessageBody'), 
    'Testing', GlobalVariable.G_Timeout)

Mobile.tap(findTestObject('Mobile/Application/OS/SMS Messaging/android.widget.Button-Send'), GlobalVariable.G_Timeout)

def textAlert = Mobile.getText(findTestObject('Mobile/Application/OS/SMS Messaging/android.widget.TextView0-Unfortunately'), 
    GlobalVariable.G_Timeout)

Mobile.verifyEqual(textAlert, 'Unfortunately, API Demos has stopped.')

@com.kms.katalon.core.annotation.SetUp
def Setup() {
    def appPath = PathUtil.relativeToAbsolutePath(GlobalVariable.G_AndroidApp, RunConfiguration.getProjectDir())

    Mobile.startApplication(appPath, false)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	Mobile.closeApplication()
}


