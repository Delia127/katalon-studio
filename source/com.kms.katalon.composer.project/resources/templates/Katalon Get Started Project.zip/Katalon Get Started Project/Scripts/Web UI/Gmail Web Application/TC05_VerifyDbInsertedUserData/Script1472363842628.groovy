import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.util.PathUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


'execute insert 1 row to database'
CustomKeywords.'com.example.DatabaseUtils.execute'(String.format(P_sqlStrInsertUser,P_Id, P_FirstName, P_LastName, P_Password, P_Location))

'query data was inserted to database'
def rs = CustomKeywords.'com.example.DatabaseUtils.executeQuery'(String.format(P_sqlStrQueryUser,P_Id))

'rowCountbefore is number row before insert 1 row'
while (rs.next()) {
	
	'get column 1 id'
	def id = rs.getString(1)
	
	'verify Id'
	WebUI.verifyEqual(id, P_Id)
	
	'get column 2 first name'
	def firstName = rs.getString(2)
	
	'verify First Name'
	WebUI.verifyEqual(firstName, P_FirstName)
	
	'get column 3 last name'
	def lastName = rs.getString(3)
	
	'verify Last Name'
	WebUI.verifyEqual(lastName, P_LastName)
	
	'get column 4 password'
	def password = rs.getString(4)
	
	'verify Password'
	WebUI.verifyEqual(password, P_Password)
	
	'get column 5 location'
	def location = rs.getString(5)
	
	'verify Location'
	WebUI.verifyEqual(location, P_Location)
	
}

@com.kms.katalon.core.annotation.SetUp
def Setup() {
	'Connect to database'
	def absDataFilePath = PathUtil.relativeToAbsolutePath(GlobalVariable.G_DatabaseFile, RunConfiguration.getProjectDir())
	CustomKeywords.'com.example.DatabaseUtils.connectDB'(absDataFilePath)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	'Execute delete 1 row to database'
	CustomKeywords.'com.example.DatabaseUtils.execute'(String.format(P_sqlStrDelUser, P_FirstName, P_LastName, P_Password, P_Location))
	
	'Close all connect'
	CustomKeywords.'com.example.DatabaseUtils.closeDatabaseConnection'()
}
