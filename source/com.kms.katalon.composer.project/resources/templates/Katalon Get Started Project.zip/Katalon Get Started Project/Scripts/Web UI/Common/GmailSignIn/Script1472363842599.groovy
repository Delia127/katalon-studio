import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


isRelogin =  CustomKeywords.'com.example.WebUiCustomKeywords.isElementPresent'(findTestObject('Web UI/Gmail Web Application/Page_GmailSignIn/lbl_ReauthEmail'), 
    GlobalVariable.G_ShortTimeOut)

'If login the first time, Email text box is visible. If re-login, Email text box is hidden'
if (!isRelogin) {
    'Enter user email into `Enter your email` field.'
    WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Email'), GlobalVariable.G_Timeout)

    WebUI.setText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Email'), P_Username)

    WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/btn_Next'))
}

'Enter password into `Password` field'
WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Password'), 
    GlobalVariable.G_Timeout)

WebUI.setText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Password'), P_Password)

'Submit into gmail page'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/btn_Sign In'))