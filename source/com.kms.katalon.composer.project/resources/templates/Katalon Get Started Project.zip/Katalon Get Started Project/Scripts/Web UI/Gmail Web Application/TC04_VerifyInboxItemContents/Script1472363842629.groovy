import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject

'Call compose to send mail 1 and validate that email was sent successfully'
WebUI.callTestCase(findTestCase('Web UI/Common/Compose'), ['P_SendTo' : P_SendTo, 'P_Subject' : P_Subject1, 'P_Message' : P_Message])

'Validate that email was sent successfully'
WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_NotificationMessage'), 
    GlobalVariable.G_Timeout)

NotificationMessage = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_NotificationMessage'))

WebUI.verifyEqual(NotificationMessage, GlobalVariable.G_NotificationMessage)

'Call compose to send mail 2 and validate that email was sent successfully '
WebUI.callTestCase(findTestCase('Web UI/Common/Compose'), ['P_SendTo' : P_SendTo, 'P_Subject' : P_Subject2, 'P_Message' : P_Message])

'Validate that email was sent successfully'
WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_NotificationMessage'), 
    GlobalVariable.G_Timeout)

NotificationMessage = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_NotificationMessage'))

WebUI.verifyEqual(NotificationMessage, GlobalVariable.G_NotificationMessage)

'Sign out Gmail page'
WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignOut'), null)

WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignIn'), ['P_Username' : P_Username, 'P_Password' : P_Password])

'Click on `Inbox` button to verify information mail 1'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Inbox'))

'Get and open new email 1'
WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lnk_MailSub1'), 
    GlobalVariable.G_Timeout)

WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lnk_MailSub1'))

'Validate email 1 content'

'Verify information of `Send To`'
String sendTo = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_SendTo'))

WebUI.verifyEqual(sendTo.replaceAll('<', '').replaceAll('>', ''), P_SendTo)

'Verify information of `Subject`'
String subject = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_Subject'))

WebUI.verifyEqual(subject, P_Subject1)

'Verify information of `Message`'
String message = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_Message'))

WebUI.verifyEqual(message, P_Message)

'Click on `Inbox` button to verify information mail 2'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Inbox'))

'Validate email 2 content'

WebUI.waitForElementVisible(findTestObject('Web UI/Gmail Web Application/Page_GmailHome/lnk_MailSub1'), GlobalVariable.G_Timeout)

'Update xpath property of captured email web object to get email 2 object'
def ObjSubject2 = WebUI.modifyObjectProperty(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lnk_MailSub1'), 
    'xpath', 'equals', '//*[@class=\'xY a4W\']//span/b[text()=\'Email Subject 2\']', true)

'Open new email 2'
WebUI.click(ObjSubject2)

'Verify information of `Subject`'
WebUI.delay(GlobalVariable.G_ShortTimeOut)

String subject2 = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_Subject'))

WebUI.verifyEqual(subject2, P_Subject2)

@com.kms.katalon.core.annotation.SetUp
String SetUp() {
    'Sign out Gmail'
    WebUI.openBrowser(GlobalVariable.G_UrlSignOut)

    'Open browser with url'
    WebUI.navigateToUrl(GlobalVariable.G_Url)

    WebUI.maximizeWindow()

    'Call test case sign in Gmail page'
    WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignIn'), ['P_Username' : P_Username, 'P_Password' : P_Password])

    'Delete all email'
    WebUI.callTestCase(findTestCase('Web UI/Common/DeleteAllEmails'), null)
}

@com.kms.katalon.core.annotation.TearDown
String TearDown() {
    'Call test case sign out Gmail page'
    WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignOut'), null)

    'Close browser'
    WebUI.closeBrowser()
}

