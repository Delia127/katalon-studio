import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import internal.GlobalVariable as GlobalVariable


isRelogin =  CustomKeywords.'com.example.WebUiCustomKeywords.isElementPresent'(findTestObject('Web UI/Gmail Web Application/Page_GmailSignIn/lbl_ReauthEmail'), 
    GlobalVariable.G_ShortTimeOut)

'If login the first time, Email text box is visible. If re-login, Email text box is hidden'
if (!isRelogin) {
    'Enter user email into `Enter your email` field.'
    WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Email'), GlobalVariable.G_Timeout)

    WebUI.setText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Email'), P_Username)

    WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/btn_Next'))
}

'Enter password into `Password` field'
WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Password'), 
    GlobalVariable.G_Timeout)

WebUI.setText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/txt_Password'), P_Password)

'Submit into gmail page'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignIn/btn_Sign In'))