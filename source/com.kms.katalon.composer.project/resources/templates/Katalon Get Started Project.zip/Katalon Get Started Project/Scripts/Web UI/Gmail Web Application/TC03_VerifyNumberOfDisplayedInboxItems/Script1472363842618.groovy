import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import org.openqa.selenium.By
import org.openqa.selenium.WebElement

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


'Call test case compose new mail'
WebUI.callTestCase(findTestCase('Web UI/Common/Compose'), ['P_SendTo' : P_SendTo, 'P_Subject' : P_Subject
        , 'P_Message' : P_Message])

'Click on `Inbox` button to verify information new mail'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Inbox'))

'get the mail list table'
table = findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/tbl_mailList')

'Delays some seconds for mails list refreshed'
WebUI.delay(GlobalVariable.G_ShortTimeOut)

'get element rows'
List<WebElement> rows = CustomKeywords.'com.example.WebUiCustomKeywords.getHtmlTableRows'(table, 'tbody')

def countItemMail = 0

'loop over email in the Inbox'
for (WebElement row : rows) {
    'get coloum element'
    List<WebElement> columns = CustomKeywords.'com.example.WebUiCustomKeywords.getHtmlTableColumns'(row, 'td')

    'get cell element'
	WebElement cell = columns.get(5).findElement(By.xpath('.//span'))

    'get text of cell'
    def colText = cell.getText()

    'Count number of emails from specified email address'	
    if (colText.equals(P_Subject)) {
        countItemMail++
    }
}

'Validate the counted number with the expected value'
WebUI.verifyEqual(countItemMail, 1)

@com.kms.katalon.core.annotation.SetUp
def SetUp() {
	'Sign out Gmail to make sure browser not in Sign In state'
    WebUI.openBrowser(GlobalVariable.G_UrlSignOut)

    'Open browser with url'
    WebUI.navigateToUrl(GlobalVariable.G_Url)

    WebUI.maximizeWindow()
	
	'Call test case sign in Gmail page'
	WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignIn'), ['P_Username' : P_Username, 'P_Password' : P_Password])
	
	'Delete all emails'
	WebUI.callTestCase(findTestCase('Web UI/Common/DeleteAllEmails'), null)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
    'Call test case sign out Gmail page'
    WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignOut'), null)

    'Close browser'
    WebUI.closeBrowser()
}
