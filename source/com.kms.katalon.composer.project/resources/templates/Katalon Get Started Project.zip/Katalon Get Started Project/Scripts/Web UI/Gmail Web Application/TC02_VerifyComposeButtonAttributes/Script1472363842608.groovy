import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Call test case sign in Gmail page'
WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignIn'), ['P_Username' : P_Username
        , 'P_Password' : P_Password])

'Get Compose web object'
def elementValue = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Compose'))

'Verify Compose text value, expected to be \"COMPOSE\"'
WebUI.verifyEqual(elementValue, 'COMPOSE')

'Get attributes of the web object'
def attributeValue = WebUI.getAttribute(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Compose'), 'role')

"Verify Compose button's role attribute value, expected to be 'button'"
WebUI.verifyEqual(attributeValue, 'button')

@com.kms.katalon.core.annotation.SetUp
def SetUp() {
    'Sign out Gmail to make sure browser not in Sign In state'
    WebUI.openBrowser(GlobalVariable.G_UrlSignOut)

    'Open browser with url'
    WebUI.navigateToUrl(GlobalVariable.G_Url)

    WebUI.maximizeWindow()
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
    'Call test case sign out Gmail page'
    WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignOut'), null)

    'Close browser'
    WebUI.closeBrowser()
}

