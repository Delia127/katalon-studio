import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


'Compose new mail'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Compose'))

'Enter To email address'
WebUI.setText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_Compose/txt_SendTo'), P_SendTo)

'Enter Subject'
WebUI.setText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_Compose/txt_Subject'), P_Subject)

'Enter Message content'
WebUI.setText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_Compose/txt_Message'), P_Message)

'Sending mail by click on `Send` button'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_Compose/btn_Send'))

