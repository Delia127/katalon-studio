import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


'Check if there is any email to delete'
hasEmail = CustomKeywords.'com.example.WebUiCustomKeywords.isElementPresent'(findTestObject('Web UI/Gmail Web Application/Page_GmailHome/tbl_mailList'), 
	GlobalVariable.G_Timeout)

if (hasEmail) {
	'Check box to delete all mail'
	WebUI.check(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/cbx_Delete'))
	
    'Delete all mail'
    WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Delete'), 
        GlobalVariable.G_Timeout)

    WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Delete'))
	
	'Accept confirmation for delete (may happen sometime)'
	WebUI.acceptAlert(FailureHandling.OPTIONAL)
}

