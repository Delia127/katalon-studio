import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WebAPI

def requestUser = (findTestObject('Object Repository/Web API/JIRA REST API/AddUser') as RequestObject)

requestUser.getHttpHeaderProperties().add(CustomKeywords.'com.example.WebApiCustomKeywords.createBasicAuthProperty'(P_UserAdmin, P_PassAdmin))

requestUser.setHttpBody(CustomKeywords.'com.example.WebApiCustomKeywords.newHttpBody'(P_Username,P_Password,P_Email, P_DisplayName, P_Notification))

def responseUser = WebAPI.sendRequest(requestUser)

return responseUser
