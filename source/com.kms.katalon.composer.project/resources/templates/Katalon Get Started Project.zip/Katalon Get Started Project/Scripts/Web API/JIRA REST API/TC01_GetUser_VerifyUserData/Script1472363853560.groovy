import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WebAPI

def requestUser = (findTestObject('Object Repository/Web API/JIRA REST API/GetUser') as RequestObject)

requestUser.getHttpHeaderProperties().add(CustomKeywords.'com.example.WebApiCustomKeywords.createBasicAuthProperty'(P_UserAdmin,P_PassAdmin))

requestUser.getRestParameters().add(new TestObjectProperty(GlobalVariable.G_JSON_USER_NAME_PROP, ConditionType.EQUALS, P_Username, true))

def responseUser = WebAPI.sendRequest(requestUser)

WebAPI.verifyElementPropertyValue(responseUser, GlobalVariable.G_JSON_NAME_PROP, P_Username)

@com.kms.katalon.core.annotation.SetUp
def Setup() {
	'Call add the new user'
	WebAPI.callTestCase(findTestCase('Web API/Common/AddUserApi'), ['P_Username' : P_Username, 'P_Password' : 'admin123', 'P_Email' : 'example@example.com',
		'P_DisplayName' : 'NewDisplayName', 'P_Notification' : 'NewNotification', 'P_UserAdmin' : P_UserAdmin, 'P_PassAdmin' : P_PassAdmin ])
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	'Call delete the user'
	WebAPI.callTestCase(findTestCase('Web API/Common/DeleteUserApi'), ['P_DeleteUser' : P_Username, 'P_UserAdmin' : P_UserAdmin, 'P_PassAdmin' : P_PassAdmin])
}

