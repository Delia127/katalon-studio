import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WebAPI

def request = (findTestObject('Object Repository/Web API/JIRA REST API/GetSession') as RequestObject)

reponse = WebAPI.sendRequest(request)

def requestUser = (findTestObject('Object Repository/Web API/JIRA REST API/GetUser') as RequestObject)

requestUser.getHttpHeaderProperties().add(CustomKeywords.'com.example.WebApiCustomKeywords.createBasicAuthProperty'(P_UserAdmin, P_PassAdmin))

requestUser.getRestParameters().add(new TestObjectProperty(GlobalVariable.G_JSON_USER_NAME_PROP, ConditionType.EQUALS, P_Username, true))

def responseUser = WebAPI.sendRequest(requestUser)

return responseUser
