import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WebAPI
import com.kms.katalon.core.testobject.ResponseObject

def requestDelUser = (ObjectRepository.findTestObject('Object Repository/Web API/JIRA REST API/DeleteUser') as RequestObject)

requestDelUser.getHttpHeaderProperties().add(CustomKeywords.'com.example.WebApiCustomKeywords.createBasicAuthProperty'(P_UserAdmin,P_PassAdmin))

requestDelUser.getRestParameters().add(new TestObjectProperty("username", ConditionType.EQUALS, P_Username, true))

def response = WebAPI.sendRequest(requestDelUser)

'Call verify the user no loger exist'
def responseUser = WebAPI.callTestCase(findTestCase('Web API/Common/GetUserApi'), ['P_Username' : P_Username, 'P_UserAdmin' : P_UserAdmin, 'P_PassAdmin' : P_PassAdmin])	

WebAPI.verifyElementPropertyValue(responseUser, "errorMessages[0]", "The user named '"+ P_Username +"' does not exist")

@com.kms.katalon.core.annotation.SetUp
def Setup() {
	'Call add a new user'
	WebAPI.callTestCase(findTestCase('Web API/Common/AddUserApi'), ['P_Username' : P_Username, 'P_Password' : 'username123', 'P_Email' : 'example@example.com',
		'P_DisplayName' : 'NewDisplayName', 'P_Notification' : 'NewNotification' ])
	'Call add get user and verify'
	def responseUser = WebAPI.callTestCase(findTestCase('Web API/Common/GetUserApi'), ['P_Username' : P_Username, 'P_UserAdmin' : P_UserAdmin, 'P_PassAdmin' : P_PassAdmin])	
	WebAPI.verifyElementPropertyValue(responseUser, "name", P_Username)
}

