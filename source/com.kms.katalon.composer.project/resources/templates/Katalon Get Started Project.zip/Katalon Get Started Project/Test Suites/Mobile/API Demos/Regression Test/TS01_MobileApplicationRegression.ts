<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS01_MobileApplicationRegression</name>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>f1d86e29-efbb-49f9-8544-aa50a5d5db28</testSuiteGuid>
   <testCaseLink>
      <guid>d735c56d-b8fc-4fac-8ed0-d0d35aea63c9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mobile/API Demos/TC01_GetItems_GetItemsDataListShowFull</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>85364e99-ed7d-4b4d-a6c5-1d792e1a02bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mobile/API Demos/TC02_SendMessage_VerifySendMessageUnSuccessfully</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>200d8b32-ca31-4423-bba9-967640dd04e0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mobile/API Demos/TC03_ScrollUpDownList_ScrollUpDownListAndVerifyLastItems</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f5e97dbe-67ec-4b5f-8b34-ce13a800aa54</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mobile/API Demos/TC04_GetAttributeItem_VerifyTheAttributeOfDefaultItem</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>92ab2281-7c53-49d3-baae-edb9da37db8e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Mobile/API Demos/TC05_CheckAlarmMessage_VerifyAlarmMessageShowCorrect</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
