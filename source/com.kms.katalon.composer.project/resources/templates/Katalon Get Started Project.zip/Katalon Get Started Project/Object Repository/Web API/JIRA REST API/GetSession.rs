<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>GetSession</name>
   <elementGuidId>c38cbb54-2e86-4905-a424-63a0de42344c</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody>{   
    &quot;username&quot;: &quot;admin&quot;,
    &quot;password&quot;: &quot;kmskatalon&quot;    
}</httpBody>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://katalon.atlassian.net/rest/auth/1/session</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
