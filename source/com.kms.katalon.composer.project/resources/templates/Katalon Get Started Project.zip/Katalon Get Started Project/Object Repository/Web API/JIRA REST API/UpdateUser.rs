<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>UpdateUser</name>
   <elementGuidId>db1629c9-f548-4dad-8490-344d4a8cbf74</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody>{
&quot;name&quot;: &quot;Truc&quot;,
&quot;password&quot;: &quot;admin@123&quot;,
&quot;emailAddress&quot;: &quot;trucvo@kms-technology.com&quot;,
&quot;displayName&quot;: &quot;hello Truc updated&quot;,
&quot;notification&quot; : &quot;hello Truc updated&quot;
}</httpBody>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <restRequestMethod>PUT</restRequestMethod>
   <restUrl>https://katalon.atlassian.net/rest/api/2/user</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
