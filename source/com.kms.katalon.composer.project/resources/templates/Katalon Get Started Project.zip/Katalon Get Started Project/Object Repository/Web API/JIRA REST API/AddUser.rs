<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>AddUser</name>
   <elementGuidId>e96ec9dd-e488-4ab8-b343-f41ec4dffc55</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody>{
&quot;name&quot;: &quot;%s&quot;,
&quot;password&quot;: &quot;%s&quot;,
&quot;emailAddress&quot;: &quot;%s&quot;,
&quot;displayName&quot;: &quot;%s&quot;,
&quot;notification&quot; : &quot;Hello&quot;
}</httpBody>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://katalon.atlassian.net/rest/api/2/user</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
