<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_NotificationMessage</name>
   <elementGuidId>df16a750-7682-45b8-a0a9-f623d4849175</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='vh'][1]</value>
   </webElementProperties>
</WebElementEntity>
