<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Subject</name>
   <elementGuidId>2044f74b-ac86-4333-a900-8250da0902b5</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//table[@class='Bs nH iY']//h2[@class='hP']</value>
   </webElementProperties>
</WebElementEntity>
