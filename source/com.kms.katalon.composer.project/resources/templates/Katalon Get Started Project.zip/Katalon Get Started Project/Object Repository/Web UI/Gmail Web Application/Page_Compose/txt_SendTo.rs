<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_SendTo</name>
   <elementGuidId>8497df7f-683f-4f38-9560-48da9a7815d8</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>to</value>
   </webElementProperties>
</WebElementEntity>
