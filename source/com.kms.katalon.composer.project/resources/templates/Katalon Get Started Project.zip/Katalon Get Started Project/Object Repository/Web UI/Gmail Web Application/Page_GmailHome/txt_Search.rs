<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Search</name>
   <elementGuidId>37937a58-4e80-4ad5-93ce-123c32b1156f</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>gbqfq</value>
   </webElementProperties>
</WebElementEntity>
