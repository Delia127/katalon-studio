<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cbx_Delete</name>
   <elementGuidId>6b956fba-402c-4f01-bd84-28e3a35462e8</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class='T-Jo J-J5-Ji' and @role='checkbox'])[1]</value>
   </webElementProperties>
</WebElementEntity>
