<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_Google Account</name>
   <elementGuidId>809511c1-418e-4150-a4b0-540608537ea8</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;gb&quot;]/div[1]/div[1]/div[2]/div[4]/div[1]/a/span</value>
   </webElementProperties>
</WebElementEntity>
