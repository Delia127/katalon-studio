<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Message</name>
   <elementGuidId>7a2ffad6-e55b-4cee-b49d-4effab0ad337</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='ii gt adP adO']</value>
   </webElementProperties>
</WebElementEntity>
