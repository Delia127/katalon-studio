<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Compose</name>
   <elementGuidId>99604cef-8fa8-4be1-9208-a2e630e5d7a4</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[text()='COMPOSE']</value>
   </webElementProperties>
</WebElementEntity>
