<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Sign Out</name>
   <elementGuidId>9817ea8e-4d77-49a1-9cc3-e4a92941d3bb</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>gb_71</value>
   </webElementProperties>
</WebElementEntity>
