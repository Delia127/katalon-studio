<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Sign In</name>
   <elementGuidId>25b7192e-771e-4cdd-b1f4-52d07d3aa92f</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>signIn</value>
   </webElementProperties>
</WebElementEntity>
