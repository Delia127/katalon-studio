<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_NewMail</name>
   <elementGuidId>52db39b5-f76e-4894-9b69-f56ebdaa0f43</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='zA zE'][1]</value>
   </webElementProperties>
</WebElementEntity>
