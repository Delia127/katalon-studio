<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Message</name>
   <elementGuidId>b822bc9b-896d-452b-a69d-6c53443e5791</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@aria-label='Message Body'][@role='textbox']</value>
   </webElementProperties>
</WebElementEntity>
