<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_MailSub1</name>
   <elementGuidId>d7597d2d-e446-4633-b4b1-919c0e110386</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='xY a4W']//span/b[text()='Email Subject 1']</value>
   </webElementProperties>
</WebElementEntity>
