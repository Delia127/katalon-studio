<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Password</name>
   <elementGuidId>5a09d1ec-4b1c-462b-a79a-5eded4172d5c</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>Passwd</value>
   </webElementProperties>
</WebElementEntity>
