<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tbl_mailList</name>
   <elementGuidId>762be111-7d17-498a-99cb-22d2cb234c0c</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='F cf zt']</value>
   </webElementProperties>
</WebElementEntity>
