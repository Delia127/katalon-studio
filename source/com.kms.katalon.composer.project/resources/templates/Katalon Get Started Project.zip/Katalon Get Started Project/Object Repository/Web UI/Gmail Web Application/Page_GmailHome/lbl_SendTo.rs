<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_SendTo</name>
   <elementGuidId>b5c11b44-0147-403b-8bf1-aa489437a4e4</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Katalon KMS']/following-sibling::span[@class='go']</value>
   </webElementProperties>
</WebElementEntity>
