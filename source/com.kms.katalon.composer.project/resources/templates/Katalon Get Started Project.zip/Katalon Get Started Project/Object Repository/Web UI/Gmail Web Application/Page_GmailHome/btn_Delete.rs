<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Delete</name>
   <elementGuidId>30868a16-570a-4a0f-af10-5c54bb50b8ce</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='Cq aqL' and @gh='mtb']//div[@class = 'ar9 T-I-J3 J-J5-Ji']</value>
   </webElementProperties>
</WebElementEntity>
