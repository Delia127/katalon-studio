<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Search</name>
   <elementGuidId>595a58fc-9a52-48da-8b58-ffe2ba35c63c</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>gbqfb</value>
   </webElementProperties>
</WebElementEntity>
