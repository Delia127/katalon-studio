<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Next</name>
   <elementGuidId>97ec1f9f-b6da-47e7-aa45-6d99dfb3e7df</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>next</value>
   </webElementProperties>
</WebElementEntity>
