<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_SendTo</name>
   <elementGuidId>564ac15e-a3f0-4784-8954-c8b69b96167a</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>composeto</value>
   </webElementProperties>
</WebElementEntity>
