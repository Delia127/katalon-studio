<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Subject</name>
   <elementGuidId>834e8b29-d928-451f-9d88-14a7507752c6</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>cmcsubj</value>
   </webElementProperties>
</WebElementEntity>
