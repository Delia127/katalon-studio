<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Delete</name>
   <elementGuidId>546da00d-6aa3-41a9-9322-0387e818baa6</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;:5&quot;]/div[2]/div[1]/div/div[2]/div[3]</value>
   </webElementProperties>
</WebElementEntity>
