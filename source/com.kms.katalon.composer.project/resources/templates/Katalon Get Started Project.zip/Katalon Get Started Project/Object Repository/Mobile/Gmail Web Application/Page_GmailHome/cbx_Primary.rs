<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cbx_Primary</name>
   <elementGuidId>172dbfdf-61b6-4e9e-81e1-f41722d1a994</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='M j Nl  ']</value>
   </webElementProperties>
</WebElementEntity>
