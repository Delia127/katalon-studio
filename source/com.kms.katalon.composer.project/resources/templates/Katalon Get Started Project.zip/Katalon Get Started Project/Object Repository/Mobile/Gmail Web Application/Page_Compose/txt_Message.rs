<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Message</name>
   <elementGuidId>67c8e6e4-9485-497b-a843-ce41d4d3d538</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>cmcbody</value>
   </webElementProperties>
</WebElementEntity>
