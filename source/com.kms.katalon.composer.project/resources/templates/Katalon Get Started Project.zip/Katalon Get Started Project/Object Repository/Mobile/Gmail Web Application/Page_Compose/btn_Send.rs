<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Send</name>
   <elementGuidId>aea89e83-ebbb-44d2-b1c7-9fc444a67ee5</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class='M j T b hc Om Ce']</value>
   </webElementProperties>
</WebElementEntity>
