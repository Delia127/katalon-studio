<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>Get list user of Jira site</description>
   <name>GetUser</name>
   <elementGuidId>d71dd38c-4839-4987-9f4c-1b352a9b121a</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <httpBody></httpBody>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Content-Type</name>
      <type>Main</type>
      <value>application/json</value>
   </httpHeaderProperties>
   <restRequestMethod>GET</restRequestMethod>
   <restUrl>https://katalon.atlassian.net/rest/api/2/user</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceFunction></soapServiceFunction>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
