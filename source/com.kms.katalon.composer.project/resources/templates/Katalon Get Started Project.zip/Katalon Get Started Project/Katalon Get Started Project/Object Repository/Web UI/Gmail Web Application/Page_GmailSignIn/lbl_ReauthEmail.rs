<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_ReauthEmail</name>
   <elementGuidId>0df73258-ff83-4508-b7d7-7b9c0c13dc93</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>reauthEmail</value>
   </webElementProperties>
</WebElementEntity>
