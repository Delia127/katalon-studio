<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Compose</name>
   <elementGuidId>88058b71-8ce4-464c-94af-568d7efe4946</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;tltbt&quot;]/div[4]/div/div</value>
   </webElementProperties>
</WebElementEntity>
