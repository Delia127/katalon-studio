<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Send</name>
   <elementGuidId>fa5f78c9-f51f-4249-98a2-fdad905cf9b1</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[text()='Send']</value>
   </webElementProperties>
</WebElementEntity>
