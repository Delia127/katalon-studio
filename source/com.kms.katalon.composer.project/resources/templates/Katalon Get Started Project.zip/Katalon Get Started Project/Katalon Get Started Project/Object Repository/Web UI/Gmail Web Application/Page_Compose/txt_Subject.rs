<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Subject</name>
   <elementGuidId>1fe70da2-2710-44fb-94f4-8de2c5a40c13</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[contains(@name,'subject')][@spellcheck]</value>
   </webElementProperties>
</WebElementEntity>
