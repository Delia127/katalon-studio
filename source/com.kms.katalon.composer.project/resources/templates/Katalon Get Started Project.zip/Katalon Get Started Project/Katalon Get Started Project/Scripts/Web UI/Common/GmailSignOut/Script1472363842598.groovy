import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'On the right, click on `google account` icon'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignOut/lnk_Google Account'))

WebUI.waitForElementPresent(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignOut/btn_Sign Out'), 
    GlobalVariable.G_Timeout)

'Log out by click on `Sign out` button'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailSignOut/btn_Sign Out'))

