import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Call compose new email'
WebUI.callTestCase(findTestCase('Web UI/Common/Compose'), ['P_SendTo' : P_SendTo, 'P_Subject' : P_Subject
		, 'P_Message' : P_Message])

'Validate that email was sent successfully'
WebUI.waitForElementVisible(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_NotificationMessage'),
	GlobalVariable.G_Timeout)

NotificationMessage = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_NotificationMessage'))

WebUI.verifyEqual(NotificationMessage, GlobalVariable.G_NotificationMessage)

'Sign out Gmail page'
WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignOut'), null)

'Sign in Gmail page again'
WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignIn'), ['P_Username' : P_Username, 'P_Password' : P_Password])

'Click on `Inbox` button to verify information new mail'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/btn_Inbox'))

'Get and open new email'
WebUI.click(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lnk_NewMail'))

'Verify `Send To` value'
def sendTo = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_SendTo'))

WebUI.verifyEqual(sendTo.replaceAll('<', '').replaceAll('>', ''), P_SendTo)

'Verify `Subject` value'
def subject = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_Subject'))

WebUI.verifyEqual(subject, P_Subject, FailureHandling.STOP_ON_FAILURE)

'Verify `Message` value'
def message = WebUI.getText(findTestObject('Object Repository/Web UI/Gmail Web Application/Page_GmailHome/lbl_Message'))

WebUI.verifyEqual(message, P_Message)

@com.kms.katalon.core.annotation.SetUp
def SetUp() {
    'Sign out Gmail to make sure browser not in Sign In state'
    WebUI.openBrowser(GlobalVariable.G_UrlSignOut)

    'Open browser with url'
    WebUI.navigateToUrl(GlobalVariable.G_Url)

    WebUI.maximizeWindow()
	
	'Call test case sign in Gmail page'
	WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignIn'), ['P_Username' : P_Username, 'P_Password' : P_Password])
	
	'Delete all emails'
	WebUI.callTestCase(findTestCase('Web UI/Common/DeleteAllEmails'), null)
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	'Call test case sign out Gmail page'
	WebUI.callTestCase(findTestCase('Web UI/Common/GmailSignOut'), null)

	'Close browser'
	WebUI.closeBrowser()
}

