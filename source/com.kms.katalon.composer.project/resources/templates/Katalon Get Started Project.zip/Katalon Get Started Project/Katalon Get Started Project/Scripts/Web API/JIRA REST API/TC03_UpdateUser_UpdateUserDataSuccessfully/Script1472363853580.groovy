import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import internal.GlobalVariable

import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WebAPI

requestUser = (findTestObject('Object Repository/Web API/JIRA REST API/UpdateUser') as RequestObject)

requestUser.getHttpHeaderProperties().add(CustomKeywords.'com.example.WebApiCustomKeywords.createBasicAuthProperty'(P_UserAdmin,P_PassAdmin))

requestUser.getRestParameters().add(new TestObjectProperty(GlobalVariable.G_JSON_USER_NAME_PROP, ConditionType.EQUALS, P_NewUser, true))

requestUser.setHttpBody(CustomKeywords.'com.example.WebApiCustomKeywords.updateHttpBody'("admin123","emailupdate@example.com","Update displayname", "newuser"))

responseUser = WebAPI.sendRequest(requestUser)

'Call get the user data is updated'
def responseUser = WebAPI.callTestCase(findTestCase('Web API/Common/GetUserApi'), ['P_Username' : P_NewUser, 'P_UserAdmin' : P_UserAdmin, 'P_PassAdmin' : P_PassAdmin])

WebAPI.verifyElementPropertyValue(responseUser, GlobalVariable.G_JSON_DISP_NAME_PROP, "Update displayname")

WebAPI.verifyElementPropertyValue(responseUser, GlobalVariable.G_JSON_EMAIL_ADDR_PROP, "emailupdate@example.com")

@com.kms.katalon.core.annotation.SetUp
def Setup() {
	'Call add a new user'
	WebAPI.callTestCase(findTestCase('Web API/Common/AddUserApi'), ['P_Username' : P_NewUser, 'P_Password' : P_NewPass, 'P_Email' : P_NewEmail,
		'P_DisplayName' : P_NewDisplayName, 'P_Notification' : P_NewNotification ])
}

@com.kms.katalon.core.annotation.TearDown
def TearDown() {
	'Call delete the user'
	WebAPI.callTestCase(findTestCase('Web API/Common/DeleteUserApi'), ['P_DeleteUser' : P_NewUser,'P_UserAdmin' : P_UserAdmin, 'P_PassAdmin' : P_PassAdmin])
}