

import com.kms.katalon.core.testobject.TestObject

import org.openqa.selenium.WebElement


def static "com.example.WebApiCustomKeywords.createBasicAuthProperty"(
    	String usernameAdmin	
     , 	String password	) {
    (new com.example.WebApiCustomKeywords()).createBasicAuthProperty(
        	usernameAdmin
         , 	password)
}

def static "com.example.WebApiCustomKeywords.updateHttpBody"(
    	String password	
     , 	String emailAddress	
     , 	String displayName	
     , 	String notification	) {
    (new com.example.WebApiCustomKeywords()).updateHttpBody(
        	password
         , 	emailAddress
         , 	displayName
         , 	notification)
}

def static "com.example.WebApiCustomKeywords.newHttpBody"(
    	String username	
     , 	String password	
     , 	String emailAddress	
     , 	String displayName	
     , 	String notification	) {
    (new com.example.WebApiCustomKeywords()).newHttpBody(
        	username
         , 	password
         , 	emailAddress
         , 	displayName
         , 	notification)
}

def static "com.example.DatabaseUtils.connectDB"(
    	String dataFile	) {
    (new com.example.DatabaseUtils()).connectDB(
        	dataFile)
}

def static "com.example.DatabaseUtils.executeQuery"(
    	String queryString	) {
    (new com.example.DatabaseUtils()).executeQuery(
        	queryString)
}

def static "com.example.DatabaseUtils.closeDatabaseConnection"() {
    (new com.example.DatabaseUtils()).closeDatabaseConnection()
}

def static "com.example.DatabaseUtils.execute"(
    	String queryString	) {
    (new com.example.DatabaseUtils()).execute(
        	queryString)
}

def static "com.example.WebUiCustomKeywords.isElementPresent"(
    	TestObject to	
     , 	int timeout	) {
    (new com.example.WebUiCustomKeywords()).isElementPresent(
        	to
         , 	timeout)
}

def static "com.example.WebUiCustomKeywords.getHtmlTableRows"(
    	TestObject table	
     , 	String outerTagName	) {
    (new com.example.WebUiCustomKeywords()).getHtmlTableRows(
        	table
         , 	outerTagName)
}

def static "com.example.WebUiCustomKeywords.getHtmlTableColumns"(
    	WebElement row	
     , 	String tagName	) {
    (new com.example.WebUiCustomKeywords()).getHtmlTableColumns(
        	row
         , 	tagName)
}
