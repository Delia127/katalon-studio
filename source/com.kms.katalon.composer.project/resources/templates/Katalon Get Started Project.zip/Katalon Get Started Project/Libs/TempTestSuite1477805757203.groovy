import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.reporting.ReportUtil
import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.testdata.TestDataColumn
import groovy.lang.MissingPropertyException
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData



def static runTestCase_0() {
    TestCaseMain.runTestCase('Test Cases/Web UI/Gmail Web Application/TC01_ComposeAndSendEmail', new TestCaseBinding('Test Cases/Web UI/Gmail Web Application/TC01_ComposeAndSendEmail',  [ 'P_SendTo' : 'katalongetstartedproject@gmail.com' , 'P_Username' : 'katalongetstartedproject@gmail.com' , 'P_Message' : 'Welcome to Katalon Studio' , 'P_Subject' : 'Katalon sample script - Getting started with WebUI testing' , 'P_Password' : 'kms@katalon2016' ,  ]), FailureHandling.STOP_ON_FAILURE)
}

def static runTestCase_1() {
    TestCaseMain.runTestCase('Test Cases/Web UI/Gmail Web Application/TC02_VerifyComposeButtonAttributes', new TestCaseBinding('Test Cases/Web UI/Gmail Web Application/TC02_VerifyComposeButtonAttributes',  [ 'P_Username' : 'katalongetstartedproject@gmail.com' , 'P_Password' : 'kms@katalon2016' ,  ]), FailureHandling.STOP_ON_FAILURE)
}

def static runTestCase_2() {
    TestCaseMain.runTestCase('Test Cases/Web UI/Gmail Web Application/TC03_VerifyNumberOfDisplayedInboxItems', new TestCaseBinding('Test Cases/Web UI/Gmail Web Application/TC03_VerifyNumberOfDisplayedInboxItems',  [ 'P_SendTo' : 'katalongetstartedproject@gmail.com' , 'P_Username' : 'katalongetstartedproject@gmail.com' , 'P_Message' : 'Welcome to Katalon Studio' , 'P_Subject' : 'Katalon sample script - Getting started with WebUI testing' , 'P_Password' : 'kms@katalon2016' ,  ]), FailureHandling.STOP_ON_FAILURE)
}

def static runTestCase_3() {
    TestCaseMain.runTestCase('Test Cases/Web UI/Gmail Web Application/TC04_VerifyInboxItemContents', new TestCaseBinding('Test Cases/Web UI/Gmail Web Application/TC04_VerifyInboxItemContents',  [ 'P_SendTo' : 'katalongetstartedproject@gmail.com' , 'P_Username' : 'katalongetstartedproject@gmail.com' , 'P_Message' : 'Welcome to Katalon Studio' , 'P_Password' : 'kms@katalon2016' ,  ]), FailureHandling.STOP_ON_FAILURE)
}

def static runTestCase_4() {
    TestCaseMain.runTestCase('Test Cases/Web UI/Gmail Web Application/TC05_VerifyDbInsertedUserData', new TestCaseBinding('Test Cases/Web UI/Gmail Web Application/TC05_VerifyDbInsertedUserData',  [ 'P_LastName' : 'Pan' , 'P_Location' : 'Atlanta' , 'P_Id' : '6' , 'P_sqlStrQueryUser' : 'SELECT * FROM users WHERE id = %s' , 'P_sqlStrDelUser' : 'DELETE FROM users WHERE FirstName = \'%s\' AND LastName = \'%s\' AND Password = \'%s\' AND Location = \'%s\'' , 'P_sqlStrInsertUser' : 'INSERT INTO users (`id`, `FirstName`, `LastName`, `Password`,`Location`) VALUES (\'%s\', \'%s\', \'%s\', \'%s\',\'%s\')' , 'P_FirstName' : 'Peter' , 'P_Password' : 'katalon@2016' ,  ]), FailureHandling.STOP_ON_FAILURE)
}


Map<String, String> suiteProperties = new HashMap<String, String>();


suiteProperties.put('id', 'Test Suites/Web UI/Regression Test/TS01_GmailWebAppRegression_ExcelData')

suiteProperties.put('name', 'TS01_GmailWebAppRegression_ExcelData')

suiteProperties.put('description', '')
 

DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())



RunConfiguration.setExecutionSettingFile("D:\\Katalon\\Katalon Get Started Project\\Katalon Get Started Project\\Reports\\Web UI\\Regression Test\\TS01_GmailWebAppRegression_ExcelData\\20161030_123557\\execution.properties")

TestCaseMain.beforeStart()

KeywordLogger.getInstance().startSuite('TS01_GmailWebAppRegression_ExcelData', suiteProperties)

(0..4).each {
    "runTestCase_${it}"()
}



KeywordLogger.getInstance().endSuite('TS01_GmailWebAppRegression_ExcelData', null)
