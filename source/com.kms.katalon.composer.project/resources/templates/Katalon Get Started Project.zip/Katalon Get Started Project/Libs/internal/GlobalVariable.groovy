package internal
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import groovy.transform.CompileStatic


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 * 
 */

@CompileStatic
public class GlobalVariable {
	 
    /**
     * <p></p>
     */
	public static Object G_Timeout = 10
	 
    /**
     * <p></p>
     */
	public static Object G_NotificationMessage = 'Your message has been sent. View message'
	 
    /**
     * <p></p>
     */
	public static Object G_UrlSignOut = 'https://accounts.google.com/logout'
	 
    /**
     * <p></p>
     */
	public static Object G_Url = 'https://accounts.google.com/ServiceLogin?service=mail&continue=https://mail.google.com/mail/#identifier'
	 
    /**
     * <p></p>
     */
	public static Object G_DatabaseFile = 'Data/Web UI/SampleDB.sqlite'
	 
    /**
     * <p></p>
     */
	public static Object G_AndroidApp = 'androidapp/APIDemos.apk'
	 
    /**
     * <p></p>
     */
	public static Object G_ShortTimeOut = 5
	 
    /**
     * <p></p>
     */
	public static Object G_JSON_USER_NAME_PROP = 'username'
	 
    /**
     * <p></p>
     */
	public static Object G_JSON_NAME_PROP = 'name'
	 
    /**
     * <p></p>
     */
	public static Object G_JSON_DISP_NAME_PROP = 'displayName'
	 
    /**
     * <p></p>
     */
	public static Object G_JSON_EMAIL_ADDR_PROP = 'emailAddress'
	 
}
