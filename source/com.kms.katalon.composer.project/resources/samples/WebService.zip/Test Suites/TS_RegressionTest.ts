<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_RegressionTest</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2016-12-28T21:11:50</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>2572ccbe-e954-4f02-bf3a-34b88501a2b3</testSuiteGuid>
   <testCaseLink>
      <guid>3f5bc9e1-39c7-4e49-8263-e6fa363b4725</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC01_REST_Verify Email from list of Comments</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3ad3fedf-7af9-416c-8ff0-4383f049d9a6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC02_SOAP_Verify Converted Weight</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
