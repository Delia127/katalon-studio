<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Facility</name>
   <tag></tag>
   <elementGuidId>92d3b773-3c29-45a7-b748-664c54dbe332</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>facility</value>
   </webElementProperties>
</WebElementEntity>
